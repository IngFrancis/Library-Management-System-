#ifndef DISPLAY_H
#define DISPLAY_H

#include <Base.h>


class Display : public Base
{
    public:
        Display();

        void showTitle();

    protected:

    private:
};

#endif // DISPLAY_H
